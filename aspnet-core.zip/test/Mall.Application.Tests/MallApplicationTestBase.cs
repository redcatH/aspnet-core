﻿namespace Mall
{
    public abstract class MallApplicationTestBase : MallTestBase<MallApplicationTestModule> 
    {

    }
}
