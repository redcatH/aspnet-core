﻿namespace Mall
{
    public abstract class MallDomainTestBase : MallTestBase<MallDomainTestModule> 
    {

    }
}
