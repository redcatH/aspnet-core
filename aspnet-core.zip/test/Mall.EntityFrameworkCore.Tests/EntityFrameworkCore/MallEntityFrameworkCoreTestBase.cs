﻿using Volo.Abp;

namespace Mall.EntityFrameworkCore
{
    public abstract class MallEntityFrameworkCoreTestBase : MallTestBase<MallEntityFrameworkCoreTestModule> 
    {

    }
}
