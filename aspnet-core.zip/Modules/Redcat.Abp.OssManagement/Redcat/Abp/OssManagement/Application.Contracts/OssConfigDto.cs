﻿namespace Redcat.Abp.OssManagement.Redcat.Abp.OssManagement.Application.Contracts
{
    public class OssConfigDto
    {
        public string uploadHost { get; set; }
        public string cdnHost { get; set; }
    }
}