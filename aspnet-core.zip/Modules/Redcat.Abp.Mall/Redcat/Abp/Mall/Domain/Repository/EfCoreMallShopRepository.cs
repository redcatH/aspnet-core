﻿using Redcat.Abp.Mall.Domain;
using Redcat.Abp.Mall.Domain.Repository;
using Redcat.Abp.Mall.EntityFrameworkCore;
using Redcat.Abp.Shops.Domin.Repository;
using Volo.Abp.EntityFrameworkCore;

namespace Redcat.Abp.Mall.Domain.Repository
{
    //public class EfCoreMallShopRepository :EfCoreShopRepositoryBase<IMallDbContext, MallShop>,IMallShopRepository
    //{
    //    public EfCoreMallShopRepository(IDbContextProvider<IMallDbContext> dbContextProvider) : base(dbContextProvider)
    //    {
    //    }
    //}
}