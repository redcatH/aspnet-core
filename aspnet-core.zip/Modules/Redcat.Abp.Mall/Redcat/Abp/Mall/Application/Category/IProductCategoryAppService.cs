﻿namespace Redcat.Abp.Mall.Application.Category
{
    public interface IProductCategoryAppService
    {

    }
}