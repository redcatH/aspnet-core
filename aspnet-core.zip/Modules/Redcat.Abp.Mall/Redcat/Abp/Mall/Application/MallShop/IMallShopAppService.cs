﻿using Volo.Abp.Application.Services;

namespace Redcat.Abp.Mall.Application
{
    public interface IMallShopAppService:IApplicationService
    {
    }
}