﻿using System;
using System.Collections.Generic;
using System.Text;
using Volo.Abp.Localization;

namespace Redcat.Abp.AppManagement.Localization
{
    [LocalizationResourceName("App")]
   public class AppResource
    {
    }
}
