﻿namespace Mall.Permissions
{
    public static class MallPermissions
    {
        public const string GroupName = "Mall";

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";
    }
}