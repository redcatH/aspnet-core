﻿using Volo.Abp.Localization;

namespace Mall.Localization
{
    [LocalizationResourceName("Mall")]
    public class MallResource
    {

    }
}