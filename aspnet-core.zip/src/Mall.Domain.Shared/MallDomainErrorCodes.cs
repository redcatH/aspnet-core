﻿namespace Mall
{
    public static class MallDomainErrorCodes
    {
        /* You can add your business exception error codes here, as constants */
    }
}
