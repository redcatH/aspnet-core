﻿namespace Mall
{
    public static class MallConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}
