﻿namespace Mall.Settings
{
    public static class MallSettings
    {
        private const string Prefix = "Mall";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}